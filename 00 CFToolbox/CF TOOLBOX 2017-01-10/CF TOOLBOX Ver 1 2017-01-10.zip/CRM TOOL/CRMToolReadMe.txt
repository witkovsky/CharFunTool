CRMTool:  Aggregate Loss Distribution Calculator                             
Version:  1.0. (MATLAB 2016b)                                                                 
Date:     22-Nov-2016 21:38:05
Download: https://goo.gl/eJYYcw   
MATLAB File Exchange:
https://www.mathworks.com/matlabcentral/fileexchange/60419-collective-risk-model-tool  

CRMTool is an Aggregate Loss Distribution Calculator, suggested to            
evaluate the Collective Risk Model (CRM) compound Aggregate Loss              
Distribution (ALD) and the associated Value at Risk (VaR / quantiles)         
by numerical inversion of its characteristic function (CF).                   
                                                                              
CRMTool is a part of the CF TOOLBOX (The Characteristic Functions             
Toolbox) which consists of a set of algorithms for evaluating selected        
characteristic funcions and algorithms for numerical inversion of the         
(combined and/or compound) characteristic functions, used to evaluate the     
probability density function (PDF) and the cumulative distribution            
function (CDF).                                                               
                                                                              
The inversion algorithms are based on using simple trapezoidal rule           
for computing the integrals defined by the Gil-Pelaez formulae, and/or        
by using the FFT algorithm for computing the Fourier transform integrals.     
  